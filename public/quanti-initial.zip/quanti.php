<?php
/**
 * Plugin Name: QUANTI – Group Buying & Deals
 * Plugin URI: https://github.com/e3g-group/quanti
 * Description: Modern, secure group buying and deal orchestration with enhanced REST API for external integrations.
 * Version: 1.0.0
 * Author: E³ Group
 * Author URI: https://e3g.dev
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: quanti
 * Domain Path: /languages
 *
 * @package quanti
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

// Constants.
define( 'QUANTI_VERSION', '1.0.0' );
define( 'QUANTI_FILE', __FILE__ );
define( 'QUANTI_DIR', plugin_dir_path( __FILE__ ) );
define( 'QUANTI_URL', plugin_dir_url( __FILE__ ) );

// Composer autoload (optional, but recommended).
$autoload = QUANTI_DIR . 'vendor/autoload.php';
if ( file_exists( $autoload ) ) {
    require_once $autoload;
} else {
    // Fallback lightweight autoloader for src/ if Composer isn't used yet.
    spl_autoload_register( function ( $class ) {
        if ( strpos( $class, 'E3G\\Quanti\\' ) !== 0 ) return;
        $rel = str_replace( ['E3G\\Quanti\\', '\\'], ['', '/'], $class );
        $file = QUANTI_DIR . 'src/' . $rel . '.php';
        if ( file_exists( $file ) ) require_once $file;
    });
}

// Load text domain.
add_action( 'plugins_loaded', function() {
    load_plugin_textdomain( 'quanti', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
});

// Bootstrap plugin.
add_action( 'init', function() {
    E3G\Quanti\Plugin::instance()->init();
});

// Admin assets.
add_action( 'admin_enqueue_scripts', function( $hook ) {
    wp_register_style( 'quanti-admin', QUANTI_URL . 'assets/admin/css/admin.css', [], QUANTI_VERSION );
    wp_register_script( 'quanti-admin', QUANTI_URL . 'assets/admin/js/admin.js', ['wp-api', 'wp-i18n'], QUANTI_VERSION, true );
    if ( strpos( $hook, 'quanti' ) !== false ) {
        wp_enqueue_style( 'quanti-admin' );
        wp_enqueue_script( 'quanti-admin' );
        wp_localize_script( 'quanti-admin', 'QuantiCfg', [
            'nonce' => wp_create_nonce( 'wp_rest' ),
            'rest'  => esc_url_raw( rest_url( 'quanti/v1' ) ),
        ]);
    }
});
