<?php
// Minimal bootstrap for pure PHP unit tests (no WP integration tests here).
require_once __DIR__ . '/../quanti.php';
