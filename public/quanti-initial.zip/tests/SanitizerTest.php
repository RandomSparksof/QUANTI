<?php
use PHPUnit\Framework\TestCase;
use E3G\Quanti\Services\Sanitizer;

// Shim minimal WP sanitizers for unit scope if not present.
if (!function_exists('sanitize_text_field')) {
    function sanitize_text_field($str){ return trim((string)$str); }
}
if (!function_exists('sanitize_textarea_field')) {
    function sanitize_textarea_field($str){ return trim((string)$str); }
}
if (!function_exists('wp_kses_post')) {
    function wp_kses_post($str){ return strip_tags((string)$str, '<p><a><strong><em><br>'); }
}

final class SanitizerTest extends TestCase {
    public function testDealInputBasic(): void {
        $in = ['title' => '  Hello  ', 'status' => 'publish'];
        $out = Sanitizer::deal_input($in);
        $this->assertSame('Hello', $out['title']);
        $this->assertSame('publish', $out['status']);
    }

    public function testDealInputStatusFallback(): void {
        $in = ['title' => 'X', 'status' => 'weird'];
        $out = Sanitizer::deal_input($in);
        $this->assertSame('draft', $out['status']);
    }
}
