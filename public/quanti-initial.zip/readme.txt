=== QUANTI – Group Buying & Deals ===
Contributors: e3g
Tags: group buying, deals, marketplace, ecommerce, rest api
Requires at least: 6.5
Tested up to: 6.6
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Modern, secure group buying & deals with an enhanced REST API for external integrations.

== Description ==
QUANTI provides a custom post type (quanti_deal) and a hardened REST API for listing, creating, and managing deals.
It’s designed for extensibility via WordPress hooks and external-ready integrations.

== Installation ==
1. Upload the `quanti` folder to `/wp-content/plugins/`
2. Activate via **Plugins**.
3. Go to **Deals** in the admin menu.

== Frequently Asked Questions ==
= How do I authenticate externally? =
Use WordPress Application Passwords (Basic Auth). For bearer tokens, hook into `quanti_auth_validate_bearer` (to be added in future minor).

== Changelog ==
= 1.0.0 =
* Initial public release: CPT, REST (CRUD), security baseline, CI, tests.

== Upgrade Notice ==
= 1.0.0 =
First release.
