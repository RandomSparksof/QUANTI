<?php
namespace E3G\Quanti\REST;

use WP_REST_Controller;
use WP_REST_Server;
use WP_REST_Request;
use WP_Error;
use E3G\Quanti\CPT\Deal;
use E3G\Quanti\Services\Sanitizer;

class Controller extends WP_REST_Controller {
    public function __construct() {
        $this->namespace = 'quanti/v1';
        $this->rest_base = 'deals';
    }

    public function register_routes(): void {
        register_rest_route($this->namespace, '/' . $this->rest_base, [
            [
                'methods' => WP_REST_Server::READABLE,
                'permission_callback' => [$this, 'can_read'],
                'callback' => [$this, 'list_deals'],
                'args' => [
                    'per_page' => ['type' => 'integer', 'default' => 10, 'minimum' => 1, 'maximum' => 100],
                    'page' => ['type' => 'integer', 'default' => 1, 'minimum' => 1],
                    'status' => ['type' => 'string', 'enum' => ['publish','draft','any'], 'default' => 'publish'],
                ]
            ],
            [
                'methods' => WP_REST_Server::CREATABLE,
                'permission_callback' => [$this, 'can_write'],
                'callback' => [$this, 'create_deal'],
                'args' => [
                    'title' => ['type' => 'string', 'required' => true, 'minLength' => 1],
                    'content' => ['type' => 'string', 'required' => false],
                    'excerpt' => ['type' => 'string', 'required' => false, 'maxLength' => 300],
                    'status' => ['type' => 'string', 'enum' => ['publish','draft'], 'default' => 'draft'],
                ]
            ]
        ]);

        register_rest_route($this->namespace, '/' . $this->rest_base . '/(?P<id>\d+)', [
            [
                'methods' => WP_REST_Server::READABLE,
                'permission_callback' => [$this, 'can_read'],
                'callback' => [$this, 'get_deal'],
            ],
            [
                'methods' => WP_REST_Server::EDITABLE,
                'permission_callback' => [$this, 'can_write'],
                'callback' => [$this, 'update_deal'],
            ],
            [
                'methods' => WP_REST_Server::DELETABLE,
                'permission_callback' => [$this, 'can_write'],
                'callback' => [$this, 'delete_deal'],
            ]
        ]);
    }

    /** Permissions **/
    public function can_read(): bool {
        // Public list/read permitted by default; filterable.
        return apply_filters('quanti_rest_can_read', true);
    }

    public function can_write(): bool {
        // Require capability; filterable. External systems should use Application Passwords or custom bearer gateway.
        return apply_filters('quanti_rest_can_write', current_user_can('edit_posts'));
    }

    /** Handlers **/
    public function list_deals(WP_REST_Request $req) {
        $status = $req->get_param('status');
        if ($status === 'any') { $status = ['publish','draft','pending','future','private']; }
        $q = new \WP_Query([
            'post_type' => Deal::POST_TYPE,
            'post_status' => $status,
            'posts_per_page' => (int)$req->get_param('per_page'),
            'paged' => (int)$req->get_param('page'),
            'no_found_rows' => false,
        ]);
        $items = array_map(function($p){
            return [
                'id' => $p->ID,
                'title' => get_the_title($p),
                'excerpt' => get_the_excerpt($p),
                'status' => get_post_status($p),
                'link' => get_permalink($p),
            ];
        }, $q->posts);

        return rest_ensure_response([
            'items' => $items,
            'total' => (int)$q->found_posts,
            'pages' => (int)$q->max_num_pages,
        ]);
    }

    public function get_deal(WP_REST_Request $req) {
        $id = (int)$req['id'];
        $p = get_post($id);
        if (!$p || $p->post_type !== Deal::POST_TYPE) {
            return new WP_Error('quanti_not_found', __('Deal not found', 'quanti'), ['status' => 404]);
        }
        return rest_ensure_response([
            'id' => $p->ID,
            'title' => get_the_title($p),
            'content' => apply_filters('the_content', $p->post_content),
            'status' => get_post_status($p),
            'meta' => get_post_meta($p->ID),
        ]);
    }

    public function create_deal(WP_REST_Request $req) {
        $data = Sanitizer::deal_input($req->get_params());
        $id = wp_insert_post([
            'post_type' => Deal::POST_TYPE,
            'post_title' => $data['title'],
            'post_content' => $data['content'] ?? '',
            'post_excerpt' => $data['excerpt'] ?? '',
            'post_status' => $data['status'] ?? 'draft',
        ], true);

        if (is_wp_error($id)) return $id;

        do_action('quanti_deal_created', $id, $data);
        return rest_ensure_response(['id' => (int)$id]);
    }

    public function update_deal(WP_REST_Request $req) {
        $id = (int)$req['id'];
        if (get_post_type($id) !== Deal::POST_TYPE) {
            return new WP_Error('quanti_not_found', __('Deal not found', 'quanti'), ['status' => 404]);
        }
        $data = Sanitizer::deal_input($req->get_params());
        $res = wp_update_post([
            'ID' => $id,
            'post_title' => $data['title'] ?? get_the_title($id),
            'post_content' => $data['content'] ?? get_post_field('post_content', $id),
            'post_excerpt' => $data['excerpt'] ?? get_post_field('post_excerpt', $id),
            'post_status' => $data['status'] ?? get_post_status($id),
        ], true);
        if (is_wp_error($res)) return $res;

        do_action('quanti_deal_updated', $id, $data);
        return rest_ensure_response(['id' => (int)$id, 'updated' => true]);
    }

    public function delete_deal(WP_REST_Request $req) {
        $id = (int)$req['id'];
        if (get_post_type($id) !== Deal::POST_TYPE) {
            return new WP_Error('quanti_not_found', __('Deal not found', 'quanti'), ['status' => 404]);
        }
        $force = true;
        $res = wp_delete_post($id, $force);
        if (!$res) {
            return new WP_Error('quanti_delete_failed', __('Delete failed', 'quanti'), ['status' => 500]);
        }
        do_action('quanti_deal_deleted', $id);
        return rest_ensure_response(['id' => (int)$id, 'deleted' => true]);
    }
}
