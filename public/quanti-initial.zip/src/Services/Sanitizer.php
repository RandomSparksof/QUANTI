<?php
namespace E3G\Quanti\Services;

class Sanitizer {
    public static function deal_input(array $in): array {
        $out = [];
        if (isset($in['title']))   $out['title'] = sanitize_text_field($in['title']);
        if (isset($in['excerpt'])) $out['excerpt'] = sanitize_textarea_field($in['excerpt']);
        if (isset($in['content'])) $out['content'] = wp_kses_post($in['content']);
        if (isset($in['status']))  $out['status'] = in_array($in['status'], ['publish','draft'], true) ? $in['status'] : 'draft';
        return $out;
    }
}
