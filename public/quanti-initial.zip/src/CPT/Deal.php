<?php
namespace E3G\Quanti\CPT;

class Deal {
    public const POST_TYPE = 'quanti_deal';

    public function register(): void {
        add_action('init', function() {
            $labels = [
                'name' => __('Deals', 'quanti'),
                'singular_name' => __('Deal', 'quanti'),
            ];
            $args = [
                'labels' => $labels,
                'public' => true,
                'show_in_rest' => true,
                'rest_base' => 'deals',
                'menu_icon' => 'dashicons-groups',
                'supports' => ['title', 'editor', 'excerpt', 'thumbnail'],
                'capability_type' => 'post',
                'has_archive' => true,
                'rewrite' => ['slug' => 'deals'],
            ];
            register_post_type(self::POST_TYPE, $args);
        });
    }
}
