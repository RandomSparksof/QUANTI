<?php
namespace E3G\Quanti;

use E3G\Quanti\CPT\Deal;
use E3G\Quanti\REST\Controller as RestController;

final class Plugin {
    private static $instance;

    public static function instance(): self {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }

    public function init(): void {
        // Register content types.
        (new Deal())->register();

        // REST API routes.
        add_action('rest_api_init', function() {
            (new RestController())->register_routes();
        });

        // Activation/Deactivation hooks.
        register_activation_hook(QUANTI_FILE, [self::class, 'activate']);
        register_deactivation_hook(QUANTI_FILE, [self::class, 'deactivate']);
    }

    public static function activate(): void {
        // Ensure CPTs are registered before flushing.
        (new CPT\Deal())->register();
        flush_rewrite_rules();
    }

    public static function deactivate(): void {
        flush_rewrite_rules();
    }
}
