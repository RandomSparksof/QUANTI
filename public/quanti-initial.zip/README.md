# QUANTI – Group Buying & Deals (WordPress Plugin)

**© 2025 Grayson Edwards – E³ Group. GPLv2+**

QUANTI is a modern, secure WordPress plugin for orchestrating group buying and deals, built with an enhanced, external‑ready REST API.

## Highlights
- Custom Post Type: `quanti_deal`
- Enhanced REST API: `quanti/v1/deals` (list, create, read, update, delete)
- Security: nonces, capability checks, sanitization, prepared queries (where used), i18n
- Dev UX: Composer autoload, PHPCS, PHPUnit, GitHub Actions CI

## Install (Dev)
```bash
composer install
# Zip for upload
git archive -o quanti.zip --prefix=quanti/ HEAD
```

## REST API
- `GET /wp-json/quanti/v1/deals?per_page=10&page=1`
- `POST /wp-json/quanti/v1/deals` with JSON body:
  ```json
  {"title":"My Deal","content":"<p>Details</p>","status":"draft"}
  ```
- Auth:
  - For logged-in browsers: WP REST nonce
  - For external systems: **Application Passwords** (Basic Auth) or implement custom bearer via `quanti_auth_validate_bearer` filter.

## Extensibility
- `do_action('quanti_deal_created', $post_id, $data)`
- `do_action('quanti_deal_updated', $post_id, $data)`
- `apply_filters('quanti_rest_can_write', bool)`

## Contributing
- Lint: `composer phpcs`
- Fix: `composer phpcbf`
- Test: `composer test`

## License
GPLv2 or later. See `LICENSE`.
